﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExperianAPI.Models
{
    public class AppIdentitySettings
    {
        public AlbumsUrl AlbumsUrl { get; set; }
        public PhotosUrl PhotosUrl { get; set; }
    }
    public class AlbumsUrl
    {
        public string Url { get; set; }
    }
    public class PhotosUrl
    {
        public string Url { get; set; }
    }
}
