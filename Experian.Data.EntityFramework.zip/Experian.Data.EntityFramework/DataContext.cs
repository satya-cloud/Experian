﻿using System;
using Microsoft.EntityFrameworkCore;
using Experian.Models;

namespace Experian.Data.EntityFramework
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {

        }
        public DbSet<Albums> AlbumItems { get; set; }
        public DbSet<Photos> PhotoItems { get; set; }
    }
}
