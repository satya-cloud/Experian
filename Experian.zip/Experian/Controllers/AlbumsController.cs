﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using ExperianAPI.Models;

namespace ExperianAPI.Controllers
{
    [Route("api/[controller]")]
    public class AlbumsController : Controller
    {
        private readonly DataContext _context;
        public AlbumsController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("Albums")]
        // GET: Albums
        public IActionResult Index()
        {            
            return Ok(_context.AlbumItems.ToList());
        }

        [HttpPost]
        [Route("AlbumsByUserId/{id}")]
        // GET: Albums/Details/5
        public IActionResult Details(int id)
        {
            var albums = _context.AlbumItems
                .Where(m => m.UserID == id).ToList();
            if (albums == null)
            {
                return NotFound();
            }

            return Ok(albums);
        }
    }
}
