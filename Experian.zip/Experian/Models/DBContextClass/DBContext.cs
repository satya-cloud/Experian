﻿using Experian.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace ExperianAPI.Models
{
    public class DataContext : DbContext
    {
        private readonly AppIdentitySettings _appIdentitySettings;
        public DataContext(DbContextOptions<DataContext> options, IOptions<AppIdentitySettings> appSettings)
            : base(options)
        {
            _appIdentitySettings = appSettings.Value;
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            base.OnConfiguring(builder);
        }
        public DbSet<Albums> AlbumItems { get; set; }
        public DbSet<Photos> PhotoItems { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Albums>().HasData(albumvalue());
            builder.Entity<Photos>().HasData(photovalue());
        }
        public List<Albums> albumvalue()
        {
            var albumvalue = new List<Albums>();
            string jsonStringPhotos = (new WebClient()).DownloadString(_appIdentitySettings.AlbumsUrl.Url);
            albumvalue = JsonConvert.DeserializeObject<List<Albums>>(jsonStringPhotos);
            return albumvalue;
        }
        public List<Photos> photovalue()
        {
            var photovalue = new List<Photos>();
            string jsonStringPhotos = (new WebClient()).DownloadString(_appIdentitySettings.PhotosUrl.Url);            
            photovalue = JsonConvert.DeserializeObject<List<Photos>>(jsonStringPhotos);
            return photovalue;
        }
    }
}
