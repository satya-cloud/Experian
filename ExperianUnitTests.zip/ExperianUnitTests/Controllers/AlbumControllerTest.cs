﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ExperianAPI.Controllers;
using Moq;
using ExperianAPI.Models;
using Experian.Models;
using System.Web.Http.Results;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace ExperianUnitTests.Controllers
{
    [TestClass()]
    public class AlbumControllerTest
    {
        private AlbumsController _controller;
        private Mock<DataContext> _dataContext;
        [TestInitialize]
        public void TestInitialize()
        {
            _dataContext = new Mock<DataContext>();

            _controller = new AlbumsController(_dataContext.Object);
        }
        [TestMethod()]
        public void IndexTestMethod()
        {
            var result = _controller.Index();

            var okResult = result as OkObjectResult;

            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
        }
        [TestMethod()]
        public void DetailsTestMethod()
        {
            var result = _controller.Details(1);

            var okResult = result as OkObjectResult;

            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
        }
    }
}
